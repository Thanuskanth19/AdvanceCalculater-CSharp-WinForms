﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdvanceCalculater
{
    public partial class FormTemperatureConverter : Form
    {
        public FormTemperatureConverter()
        {
            InitializeComponent();

            comboBoxFrom.Items.AddRange(new string[] { "Celsius", "Fahrenheit", "Kelvin" });
            comboBoxTo.Items.AddRange(new string[] { "Celsius", "Fahrenheit", "Kelvin" });

            comboBoxFrom.SelectedIndex = 0; // default selection
            comboBoxTo.SelectedIndex = 1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void enter_no(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            // Avoid multiple decimals
            if (btn.Text == "." && textBoxInput.Text.Contains("."))
                return;

            if (textBoxInput.Text == "0" && btn.Text != ".")
                textBoxInput.Text = btn.Text;
            else
                textBoxInput.Text += btn.Text;
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            if (textBoxInput.Text.Length > 0)
            {
                textBoxInput.Text = textBoxInput.Text.Substring(0, textBoxInput.Text.Length - 1);
            }

            if (textBoxInput.Text == "")
                textBoxInput.Text = "0";
        }

        private void buttonConvert_Click(object sender, EventArgs e)
        {
            double input;
            if (!double.TryParse(textBoxInput.Text, out input))
            {
                MessageBox.Show("Please enter a valid number.", "Input Error");
                return;
            }

            string from = comboBoxFrom.SelectedItem.ToString();
            string to = comboBoxTo.SelectedItem.ToString();
            double result = 0;

            // Convert to Celsius
            if (from == "Fahrenheit")
                input = (input - 32) * 5 / 9;
            else if (from == "Kelvin")
                input = input - 273.15;

            // Convert from Celsius to target unit
            if (to == "Fahrenheit")
                result = (input * 9 / 5) + 32;
            else if (to == "Kelvin")
                result = input + 273.15;
            else
                result = input; // Already Celsius

            // 🔸 Set the result label
            labelResult.Text = $"Result: {Math.Round(result, 2)} {getUnitSymbol(to)}";
        }
        private string getUnitSymbol(string unit)
        {
            switch (unit)
            {
                case "Celsius":
                    return "°C";
                case "Fahrenheit":
                    return "°F";
                case "Kelvin":
                    return "K";
                default:
                    return "";
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxInput.Text = "";              // Clear input box
            comboBoxFrom.SelectedIndex = 0;      // Reset combo
            comboBoxTo.SelectedIndex = 1;        // Reset combo
            labelResult.Text = "Result:";
        }

        private void but_enter(object sender, EventArgs e)
        {
            if (textBoxInput.Text.Length > 0)
            {
                textBoxInput.Text = textBoxInput.Text.Substring(0, textBoxInput.Text.Length - 1);
            }

            if (textBoxInput.Text == "")
                textBoxInput.Text = "0";
        }

        private void NumberButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            // Prevent multiple decimals
            if (btn.Text == "." && textBoxInput.Text.Contains("."))
                return;

            // Replace "0" if starting
            if (textBoxInput.Text == "0" && btn.Text != ".")
                textBoxInput.Text = btn.Text;
            else
                textBoxInput.Text += btn.Text;
        }

        private void FormTemperatureConverter_Load(object sender, EventArgs e)
        {

        }
    }
}
