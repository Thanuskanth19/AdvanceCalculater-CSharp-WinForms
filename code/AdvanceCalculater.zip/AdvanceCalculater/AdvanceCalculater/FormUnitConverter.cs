﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdvanceCalculater
{
    public partial class FormUnitConverter : Form
    {
        public FormUnitConverter()
        {
            InitializeComponent();
            comboBoxCategory.Items.AddRange(new string[] { "Length", "Weight" });
            comboBoxCategory.SelectedIndex = 0;

            UpdateUnitComboBoxes("Length");
        }

        private void UpdateUnitComboBoxes(string category)
        {
            comboBoxFrom.Items.Clear();
            comboBoxTo.Items.Clear();

            if (category == "Length")
            {
                string[] units = { "Meter", "Kilometer", "Centimeter", "Inch", "Foot" };
                comboBoxFrom.Items.AddRange(units);
                comboBoxTo.Items.AddRange(units);
            }
            else if (category == "Weight")
            {
                string[] units = { "Gram", "Kilogram", "Pound" };
                comboBoxFrom.Items.AddRange(units);
                comboBoxTo.Items.AddRange(units);
            }

            comboBoxFrom.SelectedIndex = 0;
            comboBoxTo.SelectedIndex = 1;
        }

        private void FormUnitConverter_Load(object sender, EventArgs e)
        {

        }

        private void buttonConvert_Click(object sender, EventArgs e)
        {
            double input;
            if (!double.TryParse(textBoxInput.Text, out input))
            {
                MessageBox.Show("Please enter a valid number.");
                return;
            }

            string category = comboBoxCategory.SelectedItem.ToString();
            string from = comboBoxFrom.SelectedItem.ToString();
            string to = comboBoxTo.SelectedItem.ToString();

            double result = ConvertUnit(category, input, from, to);
            label_Result.Text = $"Result: {Math.Round(result, 4)} {to}";
        }

        private double ConvertUnit(string category, double value, string fromUnit, string toUnit)
        {
            double valueInBase = value;

            // Convert to base unit (meter or gram)
            if (category == "Length")
            {
                switch (fromUnit) // Fixed: Changed 'from' to 'fromUnit'
                {
                    case "Kilometer": valueInBase *= 1000; break;
                    case "Centimeter": valueInBase /= 100; break;
                    case "Inch": valueInBase *= 0.0254; break;
                    case "Foot": valueInBase *= 0.3048; break;
                }

                // Convert from base to target
                switch (toUnit) // Fixed: Changed 'to' to 'toUnit'
                {
                    case "Kilometer": return valueInBase / 1000;
                    case "Centimeter": return valueInBase * 100;
                    case "Inch": return valueInBase / 0.0254;
                    case "Foot": return valueInBase / 0.3048;
                }
            }
            else if (category == "Weight")
            {
                switch (fromUnit) // Fixed: Changed 'from' to 'fromUnit'
                {
                    case "Kilogram": valueInBase *= 1000; break;
                    case "Pound": valueInBase *= 453.592; break;
                }

                switch (toUnit) // Fixed: Changed 'to' to 'toUnit'
                {
                    case "Kilogram": return valueInBase / 1000;
                    case "Pound": return valueInBase / 453.592;
                }
            }

            return valueInBase;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxInput.Text = "";
            comboBoxFrom.SelectedIndex = 0;
            comboBoxTo.SelectedIndex = 1;
            label_Result.Text = "Result:";
        }

        private void numbtn_enter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            // Prevent multiple decimals
            if (btn.Text == "." && textBoxInput.Text.Contains("."))
                return;

            // Replace default 0
            if (textBoxInput.Text == "0" && btn.Text != ".")
                textBoxInput.Text = btn.Text;
            else
                textBoxInput.Text += btn.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBoxInput.Text.Length > 0)
            {
                textBoxInput.Text = textBoxInput.Text.Substring(0, textBoxInput.Text.Length - 1);
            }

            // If empty, reset to 0
            if (textBoxInput.Text == "")
                textBoxInput.Text = "0";
        }
    }
}
