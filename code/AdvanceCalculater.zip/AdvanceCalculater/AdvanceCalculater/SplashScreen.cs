﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdvanceCalculater
{
    public partial class SplashScreen : Form
    {
        public SplashScreen()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop(); // Stop the timer
            Form1 mainForm = new Form1(); // Your main calculator form
            mainForm.Show();
            this.Hide(); // Or this.Close() if you don't need splash anymore
        }

        private void SplashForm_Load(object sender, EventArgs e)
        {
            timer1.Interval = 3000; // Show splash for 3 seconds (3000 ms)
            timer1.Start();
        }
    }
}
