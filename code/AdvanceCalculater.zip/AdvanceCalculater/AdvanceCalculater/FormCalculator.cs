﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdvanceCalculater
{
    public partial class FormCalculator : Form
    {
        double value = 0;
        string operation = "";
        bool operation_pressed = false;
        public FormCalculator()
        {
            InitializeComponent();
        }

        private void Button_enter(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (operation_pressed))
                textBox1.Clear();

            operation_pressed = false;
            Button b = (Button)sender;
            textBox1.Text += b.Text;
        }

        private void btn_opr(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            operation = b.Text;
            value = double.Parse(textBox1.Text);
            operation_pressed = true;
        }

        private void btn_eq_Click(object sender, EventArgs e)
        {
            switch (operation)
            {
                case "+":
                    textBox1.Text = (value + double.Parse(textBox1.Text)).ToString();
                    break;
                case "-":
                    textBox1.Text = (value - double.Parse(textBox1.Text)).ToString();
                    break;
                case "*":
                    textBox1.Text = (value * double.Parse(textBox1.Text)).ToString();
                    break;
                case "/":
                    if (double.Parse(textBox1.Text) != 0)
                        textBox1.Text = (value / double.Parse(textBox1.Text)).ToString();
                    else
                        MessageBox.Show("Divide by zero!");
                    break;
            }
        }

        private void btn_cl_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 1)
            {
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            }
            else
            {
                textBox1.Text = "0";
            }
        }

        private void btn_ce_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void btn_pm_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "0" && textBox1.Text != "")
            {
                double currentValue = double.Parse(textBox1.Text);
                currentValue *= -1;
                textBox1.Text = currentValue.ToString();
            }
        }

        private void bsin_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Sin(value * Math.PI / 180).ToString();
        }

        private void bcos_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Cos(value * Math.PI / 180).ToString();
        }

        private void btan_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Tan(value * Math.PI / 180).ToString();
        }

        private void p2_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Pow(value, 2).ToString();
        }

        private void sinh_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Sinh(value).ToString();
        }

        private void cosh_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Cosh(value).ToString();
        }

        private void tanh_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Tanh(value).ToString();
        }

        private void p3_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Pow(value, 3).ToString();
        }

        private void ln_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Log(value).ToString();
        }

        private void log_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Log10(value).ToString();
        }

        private void sqat_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Sqrt(value).ToString();
        }

        private void dev_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            if (value != 0)
                textBox1.Text = (1 / value).ToString();
            else
                MessageBox.Show("Cannot divide by zero.");
        }

        private void dec_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(textBox1.Text);
            textBox1.Text = value.ToString();
        }

        private void bin_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(double.Parse(textBox1.Text));
            textBox1.Text = Convert.ToString(value, 2);
        }

        private void oct_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(double.Parse(textBox1.Text));
            textBox1.Text = Convert.ToString(value, 8);
        }

        private void hex_Click(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(double.Parse(textBox1.Text));
            textBox1.Text = Convert.ToString(value, 16).ToUpper();
        }

        private void perce_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = (value / 100).ToString();
        }

        private void pi_Click(object sender, EventArgs e)
        {
            textBox1.Text = Math.PI.ToString();
        }

        private void mod_Click(object sender, EventArgs e)
        {
            value = double.Parse(textBox1.Text);
            operation = "MOD";
            operation_pressed = true;
        }

        private void exp_Click(object sender, EventArgs e)
        {
            double value = double.Parse(textBox1.Text);
            textBox1.Text = Math.Exp(value).ToString();
        }

        private void FormCalculator_Load(object sender, EventArgs e)
        {
           
        }
    }
}
