﻿using System;
using System.Windows.Forms;

namespace AdvanceCalculater
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Show splash screen
            SplashScreen splash = new SplashScreen();
            splash.Show();
            Application.DoEvents(); // Allows splash screen to draw

            // Wait for 3 seconds
            System.Threading.Thread.Sleep(3000);

            splash.Close(); // Close splash screen

            // Show main calculator form
            Application.Run(new Form1()); // Replace with your main form name
        }
    }
}
