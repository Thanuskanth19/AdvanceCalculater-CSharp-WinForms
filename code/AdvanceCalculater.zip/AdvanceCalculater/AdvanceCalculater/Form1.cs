﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdvanceCalculater
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void scientificCalculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCalculator calcForm = new FormCalculator();
            calcForm.MdiParent = this;
            calcForm.Show();
        }

        private void temperatureConverterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTemperatureConverter tempForm = new FormTemperatureConverter();
            tempForm.MdiParent = this;
            tempForm.Show();
        }

        private void unitConverterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUnitConverter unitForm = new FormUnitConverter();
            unitForm.MdiParent = this;
            unitForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
